package com.example.csfoodforthought

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.GridView
import android.widget.LinearLayout
import android.widget.SearchView
import androidx.fragment.app.Fragment

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        createPageButtons()
        createSearch()
        createPageFragments(null)
    }

    fun createSearch() {
        val searchView = findViewById<SearchView>(R.id.SearchBar)

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                // Gets called when user inputs something
                // 'query' holds the text entered
                createPageFragments(query)
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                // Error if this doesn't get implemented as well?
                return true
            }
        })
    }

    private fun createPageFragments(searchString: String?) {
        val fragmentContainer = findViewById<LinearLayout>(R.id.fragmentContainer)
        val fragmentManager = supportFragmentManager

        // Clear existing fragments before adding new ones
        fragmentContainer.removeAllViews()

        val numberOfFragmentsToCreate = RecipePage.recipeNames.size

        if (searchString.isNullOrEmpty()) {
            Log.d("naljdf", "dslf")
            // Display all recipes if the search string is empty or null
            for (i in 0 until numberOfFragmentsToCreate) {
                val fragment = RecipeDisplays()

                val args = Bundle()
                args.putString("recipeName", RecipePage.recipeNames[i])
                args.putInt("recipeTime", RecipePage.recipeTimes[i])
                args.putInt("recipeImage", RecipePage.recipeImageList[i])
                fragment.arguments = args

                val transaction = fragmentManager.beginTransaction()
                transaction.add(fragmentContainer.id, fragment, "FragmentTag$i")
                transaction.commit()
            }
        } else {
            // Display recipes matching the search query
            for (i in 0 until numberOfFragmentsToCreate) {
                if (RecipePage.recipeNames[i].startsWith(searchString, ignoreCase = true)) {
                    val fragment = RecipeDisplays()

                    val args = Bundle()
                    args.putString("recipeName", RecipePage.recipeNames[i])
                    args.putInt("recipeTime", RecipePage.recipeTimes[i])
                    args.putInt("recipeImage", RecipePage.recipeImageList[i])
                    fragment.arguments = args

                    val transaction = fragmentManager.beginTransaction()
                    transaction.add(fragmentContainer.id, fragment, "FragmentTag$i")
                    transaction.commit()
                }
            }
        }
    }

    fun createPageButtons() {
        val HomeBtn = findViewById<Button>(R.id.HomePageButton)
        HomeBtn.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        })
        val LikedBtn = findViewById<ImageButton>(R.id.LikedPageButton)
        LikedBtn.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, LikedPage::class.java)
            startActivity(intent)
        })
        val ListBtn = findViewById<ImageButton>(R.id.ListPageButton)
        ListBtn.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, ListPage::class.java)
            startActivity(intent)
        })
    }
}