package com.example.csfoodforthought

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView

class RecipePage : AppCompatActivity() {
    companion object {
        val recipeImageList = listOf<Int>(
            R.drawable.pasta,
            R.drawable.soup,
            R.drawable.sausages,
            R.drawable.curry,
            R.drawable.pancakes
        )
        val recipeTimes = listOf<Int>(10, 20, 8, 30, 15)
        val recipeNames = listOf("Pasta", "Soup", "Sausages", "Curry", "Pancakes")
        var recipeIngredients = listOf(
            listOf("500", "g of pasta", "1", " can of tomato sauce"),
            listOf("1", " can of soup"),
            listOf("1", " packet of sausages"),
            listOf("1", " packet of curry"),
            listOf("200", "g flour", "50", "g sugar", "200", "ml milk"));
        var recipeLiked = mutableListOf<Boolean>(false, false, false, false, false)
        lateinit var recipeMethod: List<String>
        fun initialize(context: Context) {
            recipeMethod = listOf(
                context.getString(R.string.pasta_method),
                context.getString(R.string.soup_method),
                context.getString(R.string.sausages_method),
                context.getString(R.string.curry_method),
                context.getString(R.string.pancake_method)
            )
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recipe_page)
        RecipePage.initialize(this)

        displayRecipe()
        createPageButtons()
        createShoppingListButton()
        createLikeButton()
    }

    fun displayRecipe() {
        val recipeName = intent.getStringExtra("recipeName")
        val recipenameTextView = findViewById<TextView>(R.id.recipename)
        recipenameTextView.text = recipeName

        val position = recipeNames.indexOf(recipeName)


        val recipeImage = recipeImageList[position]
        val recipeImageView = findViewById<ImageView>(R.id.recipeimage)
        recipeImageView.setImageResource(recipeImage)

        var recipeIngredientsString = ""
        for (i in 0 until recipeIngredients[position].count()) {
            recipeIngredientsString = recipeIngredientsString + recipeIngredients[position][i]
            if (i.rem(2) == 1) {
                recipeIngredientsString = recipeIngredientsString + "\n"
            }
        }
        val recipeIngredientsTextView = findViewById<TextView>(R.id.ingredients)
        recipeIngredientsTextView.text = recipeIngredientsString

        val recipeMethod = recipeMethod[position]
        val recipeMethodTextView = findViewById<TextView>(R.id.method)
        recipeMethodTextView.text = recipeMethod

        val likeButton = findViewById<ImageButton>(R.id.likeRecipeButton)
        if (recipeLiked[position]) {
            likeButton.setBackgroundResource(R.drawable.likedhearticon)
        } else {
            likeButton.setBackgroundResource(R.drawable.unlikedheart)
        }
    }

    fun createPageButtons() {
        val HomeBtn = findViewById<Button>(R.id.HomePageButton)
        HomeBtn.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        })
        val LikedBtn = findViewById<ImageButton>(R.id.LikedPageButton)
        LikedBtn.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, LikedPage::class.java)
            startActivity(intent)
        })
        val ListBtn = findViewById<ImageButton>(R.id.ListPageButton)
        ListBtn.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, ListPage::class.java)
            startActivity(intent)
        })
    }

    fun createShoppingListButton() {
        val ListBtn = findViewById<ImageButton>(R.id.addToListButton)
        ListBtn.setOnClickListener {
            Log.d("hello", ListPage.shoppingList.toString())

            val recipeName = intent.getStringExtra("recipeName")
            val position = recipeNames.indexOf(recipeName)

            for (ingredient in recipeIngredients[position].chunked(2)) {
                val ingredientText = "${ingredient[0]} ${ingredient[1]}"

                val foundIngredient = ListPage.shoppingList.find {
                    it.substringAfter(" ") == ingredient[1]
                }

                if (foundIngredient != null) {
                    val currentAmount = foundIngredient.substringBefore(" ").toIntOrNull() ?: 0
                    val additionalAmount = ingredient[0].toIntOrNull() ?: 0
                    val updatedAmount = currentAmount + additionalAmount

                    val pos = ListPage.shoppingList.indexOf(foundIngredient)
                    ListPage.shoppingList.removeAt(pos)
                    ListPage.checkedItems.removeAt(pos)
                    ListPage.shoppingList.add("$updatedAmount ${ingredient[1]}")
                    ListPage.checkedItems.add(false)
                } else {
                    ListPage.shoppingList.add(ingredientText)
                    ListPage.checkedItems.add(false)
                }
            }
        }
    }

    fun createLikeButton() {
        val likeButton = findViewById<ImageButton>(R.id.likeRecipeButton)
        likeButton.setOnClickListener {
            val recipeName = intent.getStringExtra("recipeName")
            val position = recipeNames.indexOf(recipeName)
            recipeLiked[position] = !recipeLiked[position]
            if (recipeLiked[position]) {
                likeButton.setBackgroundResource(R.drawable.likedhearticon)
            } else {
                likeButton.setBackgroundResource(R.drawable.unlikedheart)
            }
        }
    }
}

