package com.example.csfoodforthought

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout

class LikedPage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_liked_page)

        createPageButtons()
        createPageFragments()
    }

    fun createPageButtons() {
        val HomeBtn = findViewById<Button>(R.id.HomePageButton)
        HomeBtn.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        })
        val LikedBtn = findViewById<ImageButton>(R.id.LikedPageButton)
        LikedBtn.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, LikedPage::class.java)
            startActivity(intent)
        })
        val ListBtn = findViewById<ImageButton>(R.id.ListPageButton)
        ListBtn.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, ListPage::class.java)
            startActivity(intent)
        })
    }

    fun createPageFragments() {
        val fragmentContainer = findViewById<LinearLayout>(R.id.fragmentContainer)
        val fragmentManager = supportFragmentManager

        val numberOfFragmentsToCreate = RecipePage.recipeNames.size

        for (i in 0 until numberOfFragmentsToCreate) {
            if (RecipePage.recipeLiked[i]) {
                val fragment = RecipeDisplays()

                // Pass fragment parameters here
                val args = Bundle()
                args.putString("recipeName", RecipePage.recipeNames[i])
                args.putInt("recipeTime", RecipePage.recipeTimes[i])
                args.putInt("recipeImage", RecipePage.recipeImageList[i])
                fragment.arguments = args

                val transaction = fragmentManager.beginTransaction()

                transaction.add(fragmentContainer.id, fragment, "FragmentTag$i")
                transaction.commit()
            }
        }
    }
}




